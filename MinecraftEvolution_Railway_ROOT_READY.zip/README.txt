MINECRAFT EVOLUTION — PLAYABLE VOXEL SANDBOX (PHASE 2)
======================================================

This is an upgrade of the existing ClassCraft 3D prototype. It uses original colored voxel geometry and does not include Minecraft's proprietary assets. The game is a standalone browser project; it does not yet have online accounts or multiplayer.

RUN ON ANDROID (ACODE + CHROME)
-------------------------------
1. Download MinecraftEvolution_Railway_ROOT_READY.zip and extract it.
2. Open the MinecraftEvolution folder in Acode.
3. Open index.html and use Acode's Preview / Open in Browser option.
4. Keep an internet connection on so the page can load Three.js r160 from jsDelivr. The project displays a loading error if the CDN cannot be reached.
5. On the menu, choose Creative or Survival, leave or change the seed, then tap Create World.

A local server can be more reliable than opening a file directly. In Termux, from the extracted folder, run:
  pkg install python -y
  cd /path/to/MinecraftEvolution
  python -m http.server 8080
Then open http://127.0.0.1:8080 in Chrome on the same phone. Replace the example path with the actual folder path on your device.

CONTROLS
--------
PHONE
- Drag the world view to look around.
- Use the circular joystick to move; toggle RUN and CROUCH next to it.
- Hold JUMP to jump in Survival or rise while in Creative flight.
- Push the joystick down in Creative to descend while backing up.
- Select a hotbar slot, aim at a block, then tap BREAK or PLACE.
- USE eats food in Survival, places a selected placeable item, or attacks a nearby creature when a sword is selected.
- Tap 3rd person / 1st person to change camera view.

DESKTOP
- WASD or arrow keys: move.
- Click and drag to look; on compatible desktop browsers the game uses pointer lock.
- Space: jump; E: place; Q: break; F: use selected item; number keys 1–9: choose hotbar slot; Escape: pause.

PROJECT STRUCTURE
-----------------
index.html             Page and UI panels
style.css              Mobile-first layout and HUD
js/config.js           Blocks and item definitions
js/world.js            Seeded terrain, edits, chunks, hidden-face culling
js/player.js           Movement, collision, gravity, fall damage, player save data
js/inventory.js        Inventory slots, stacks, capacity, hotbar
js/crafting.js         Recipes and ingredient validation
js/entities.js         Basic wandering animals and night creatures
js/storage.js          IndexedDB save, localStorage fallback, legacy save import
js/main.js             Three.js scene, controls, menus, mining/placement, missions, day/night
TEST-CHECKLIST.txt     Automated logic checks and manual phone tests

IMPLEMENTED IN THIS BUILD
-------------------------
- Procedural, repeatable 80 x 80 terrain with 16 x 16 chunk meshes (25 chunks), face culling, plains/forest/mountain/beach/river areas, water, simple caves, ore, trees and flowers.
- Day/night lighting and sky/fog color cycle.
- First-person and third-person camera modes, mobile drag-look, desktop pointer-lock look, movement joystick, sprint toggle, crouch toggle, jump and creative flight.
- Basic collision and gravity; block placement is rejected when the block would overlap the player.
- Crosshair voxel targeting and highlighted target; break/place actions actually change the block map and rebuild affected chunk meshes.
- Nine-slot hotbar, 36-slot inventory, click-to-swap inventory slots, stack counts, creative palette, survival resource collection and inventory-capacity checks.
- Creative and Survival modes. Survival has health, hunger, fall damage, food use, respawn, tool-gated ore/stone drops and simple creatures that wander and attack at night.
- Eight validated crafting recipes (planks, sticks, torches, wooden/stone pickaxes, sword, bricks and glass).
- Four educational missions with XP rewards.
- Local save/load of seed, world edits, player state, inventory/hotbar, game mode, time, stats and nearby entities. Uses IndexedDB first and localStorage as a fallback; can import the earlier ClassCraft local save.
- Synthesized sound effects, audio toggle, sensitivity/invert-look settings, quality/render-pixel-ratio settings, pause/menu flow and runtime error reporting.

KNOWN LIMITATIONS — NOT CLAIMED AS COMPLETE
-------------------------------------------
- This is a local single-player prototype with a fixed 80 x 80 build area, not an infinite streaming world or online multiplayer platform.
- Swimming/buoyancy, water physics, storage chests, doors/fences, armor, smelting, detailed equipment durability, complex mob pathfinding, animated mining progress/particles, clouds, dynamic shadows and background music are not implemented yet.
- Creatures use simple cube models and basic wander/chase behavior. They do not navigate around obstacles intelligently.
- Mining happens immediately on tap; block hardness affects the metadata and tool/drop rules but there is no timed mining animation.
- Graphics use colored voxel materials instead of detailed textures. Low/balanced/high settings primarily adjust render pixel ratio and fog distance.
- Three.js is loaded from a CDN, so an internet connection is required unless the library is later bundled locally.
- Browser/device WebGL performance and touch behavior still need a real Android Chrome playtest. See TEST-CHECKLIST.txt. Do not treat the automated code checks as proof that every device runs perfectly.


RAILWAY HOSTING
---------------
This folder is prepared for Railway deployment. It includes package.json, server.js, and railway.toml. The Node.js static server listens on Railway's PORT and provides /health. See START-HERE.txt and RAILWAY-DEPLOY.txt for instructions. Run `npm run check` and `npm test` to validate syntax and the local HTTP server before deploying. Railway hosting does not turn local browser saves into cloud saves; the current game remains single-player.

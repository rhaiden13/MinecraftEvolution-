'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = __dirname;
const PORT = Number(process.env.PORT) || 3000;
const HOST = '0.0.0.0';

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json; charset=utf-8'
};

function send(res, status, body, contentType = 'text/plain; charset=utf-8') {
  res.writeHead(status, {
    'Content-Type': contentType,
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.setHeader('Allow', 'GET, HEAD');
    return send(res, 405, 'Method Not Allowed');
  }

  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  } catch {
    return send(res, 400, 'Bad Request');
  }

  if (pathname === '/health' || pathname === '/health/') {
    return send(res, 200, JSON.stringify({ status: 'ok', app: 'Minecraft Evolution' }), 'application/json; charset=utf-8');
  }

  if (pathname === '/') pathname = '/index.html';

  // Never expose dotfiles, Git metadata, or this server's deployment configuration.
  const blocked = /(^|\/)\./.test(pathname) || /(^|\/)(server\.js|package\.json|package-lock\.json)(\/|$)/i.test(pathname);
  if (blocked) return send(res, 404, 'Not Found');

  const fullPath = path.resolve(ROOT, `.${pathname}`);
  if (fullPath !== ROOT && !fullPath.startsWith(ROOT + path.sep)) {
    return send(res, 403, 'Forbidden');
  }

  fs.stat(fullPath, (statError, stat) => {
    if (statError || !stat.isFile()) return send(res, 404, 'Not Found');
    const contentType = MIME_TYPES[path.extname(fullPath).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': contentType,
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Cache-Control': 'no-store',
      'Content-Length': stat.size
    });
    if (req.method === 'HEAD') return res.end();
    const stream = fs.createReadStream(fullPath);
    stream.on('error', () => {
      if (!res.headersSent) send(res, 500, 'Unable to read file');
      else res.destroy();
    });
    stream.pipe(res);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`[Minecraft Evolution] Static server listening on ${HOST}:${PORT}`);
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => process.exit(0)));
}

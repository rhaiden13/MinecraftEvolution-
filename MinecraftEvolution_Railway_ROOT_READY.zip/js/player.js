(() => {
  const M=window.ME;
  class Player {
    constructor(world,mode='creative'){this.world=world;this.mode=mode;this.x=0;this.z=5;this.y=5.5;this.vy=0;this.yaw=0;this.pitch=-.12;this.onGround=false;this.sprinting=false;this.crouching=false;this.fly=false;this.health=20;this.hunger=20;this.lastDamage=0;this.fallStart=null;this.height=1.72;}
    spawn(){this.x=0;this.z=5;this.y=this.world.surfaceAt(0,5);this.vy=0;this.onGround=false;this.yaw=0;this.pitch=-.12;this.health=20;this.hunger=20;}
    setMode(mode){this.mode=mode;this.fly=mode==='creative';if(mode==='creative'){this.health=20;this.hunger=20;}}
    eyeHeight(){return this.crouching?1.15:1.55;}
    _solidAt(x,y,z){const id=this.world.getBlock(Math.floor(x+.5),Math.floor(y+.5),Math.floor(z+.5));return id!==null&&id!==7&&!!M.block(id)?.solid;}
    collides(x,y,z){const h=this.crouching?1.18:1.72;for(const sx of [-.27,.27])for(const sz of [-.27,.27]){for(let yy=y+.1;yy<y+h-.04;yy+=.38){if(this._solidAt(x+sx,yy,z+sz))return true;}}return false;}
    update(dt,dirs){
      const fast=this.sprinting&&!this.crouching?7.0: this.crouching?1.8:4.4;
      const fwdX=-Math.sin(this.yaw),fwdZ=-Math.cos(this.yaw),rightX=Math.cos(this.yaw),rightZ=-Math.sin(this.yaw);
      let dx=0,dz=0;if(dirs.forward){dx+=fwdX;dz+=fwdZ;}if(dirs.back){dx-=fwdX;dz-=fwdZ;}if(dirs.left){dx-=rightX;dz-=rightZ;}if(dirs.right){dx+=rightX;dz+=rightZ;}
      const len=Math.hypot(dx,dz)||1;dx=dx/len*fast*dt;dz=dz/len*fast*dt;
      const steps=Math.max(1,Math.ceil(Math.max(Math.abs(dx),Math.abs(dz))/.18));for(let i=0;i<steps;i++){const nx=this.x+dx/steps,nz=this.z+dz/steps;if(!this.collides(nx,this.y,this.z))this.x=nx;if(!this.collides(this.x,this.y,nz))this.z=nz;}
      this.x=Math.max(-M.WORLD_HALF+.7,Math.min(M.WORLD_HALF-.7,this.x));this.z=Math.max(-M.WORLD_HALF+.7,Math.min(M.WORLD_HALF-.7,this.z));
      if(this.mode==='creative'&&this.fly){if(dirs.jump)this.y+=6*dt;if(dirs.down)this.y-=6*dt;this.y=Math.max(M.MIN_Y+1,Math.min(M.MAX_Y+8,this.y));this.vy=0;this.onGround=false;return;}
      if(this.mode==='creative'&&dirs.jump&&this.onGround)this.vy=5.1;
      this.vy-=18*dt;const oldY=this.y;this.y+=this.vy*dt;
      if(this.vy<=0){let ground=null;for(const sx of [-.22,0,.22])for(const sz of [-.22,0,.22]){const gx=Math.floor(this.x+sx+.5),gz=Math.floor(this.z+sz+.5);const gy=Math.floor(this.y-.04+.5);const id=this.world.getBlock(gx,gy,gz);if(id!==null&&id!==7&&M.block(id)?.solid){const top=gy+.5;if(this.y<=top+.12&&(!ground||top>ground))ground=top;}}
        if(ground!==null){if(this.mode==='survival'&&this.fallStart!==null&&this.fallStart-ground>4)this.damage(Math.min(10,Math.floor((this.fallStart-ground-3)*1.4)));this.y=ground;this.vy=0;this.onGround=true;this.fallStart=null;}else if(oldY>this.y&&this.fallStart===null)this.fallStart=oldY;
      }else if(this.collides(this.x,this.y,this.z)){this.y=oldY;this.vy=0;}
      if(this.y<-10){this.damage(5);this.y=this.world.surfaceAt(Math.round(this.x),Math.round(this.z));this.vy=0;}
    }
    damage(n){if(this.mode!=='survival')return;this.health=Math.max(0,this.health-n);if(this.health===0){this.x=0;this.z=5;this.y=this.world.surfaceAt(0,5);this.health=20;this.hunger=Math.max(6,this.hunger);this.vy=0;M.onToast?.('You respawned. Keep exploring!');}}
    serialize(){return {x:this.x,y:this.y,z:this.z,vy:this.vy,yaw:this.yaw,pitch:this.pitch,health:this.health,hunger:this.hunger,sprinting:this.sprinting,crouching:this.crouching,fly:this.fly};}
    restore(d){if(!d||typeof d!=='object')return;for(const k of ['x','y','z','vy','yaw','pitch','health','hunger'])if(Number.isFinite(d[k]))this[k]=d[k];for(const k of ['sprinting','crouching','fly'])if(typeof d[k]==='boolean')this[k]=d[k];this.x=Math.max(-M.WORLD_HALF+.7,Math.min(M.WORLD_HALF-.7,this.x));this.z=Math.max(-M.WORLD_HALF+.7,Math.min(M.WORLD_HALF-.7,this.z));this.y=Math.max(M.MIN_Y+.5,Math.min(M.MAX_Y+10,this.y));this.health=Math.max(0,Math.min(20,this.health));this.hunger=Math.max(0,Math.min(20,this.hunger));this.pitch=Math.max(-1.38,Math.min(1.28,this.pitch));}
  }
  M.Player=Player;
})();

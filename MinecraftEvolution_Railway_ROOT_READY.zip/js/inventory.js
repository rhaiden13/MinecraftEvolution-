(() => {
  const M=window.ME;
  const cloneSlot=s=>s?{id:s.id,count:s.count}:null;
  class Inventory {
    constructor(mode='creative'){this.mode=mode;this.slots=Array(36).fill(null);this.active=0;this.focus=null;this.reset(mode);}
    reset(mode=this.mode){this.mode=mode;this.slots=Array(36).fill(null);this.active=0;this.focus=null;
      if(mode==='creative'){
        [0,1,2,3,4,5,6,10,13].forEach((id,i)=>this.slots[i]={id,count:64});
      }else{
        this.slots[0]={id:0,count:16};this.slots[1]={id:1,count:24};this.slots[2]={id:3,count:8};this.slots[3]={id:5,count:12};this.slots[4]={id:18,count:4};
      }
    }
    count(id){return this.slots.reduce((n,s)=>n+(s&&s.id===id?s.count:0),0);}
    has(id,count=1){return this.count(id)>=count;}
    canAdd(id,count=1){const item=M.item(id);if(!item||!Number.isInteger(count)||count<0)return false;if(count===0)return true;let capacity=0;const max=item.stack||64;for(const s of this.slots){if(!s)capacity+=max;else if(s.id===id)capacity+=Math.max(0,max-s.count);}return capacity>=count;}
    add(id,count=1){const item=M.item(id);if(!item||!Number.isInteger(count)||count<0)return false;if(count===0)return true;if(!this.canAdd(id,count))return false;let remaining=count;const max=item.stack||64;
      for(const s of this.slots){if(s&&s.id===id&&s.count<max){const n=Math.min(max-s.count,remaining);s.count+=n;remaining-=n;if(!remaining)return true;}}
      for(let i=0;i<this.slots.length;i++){if(!this.slots[i]){const n=Math.min(max,remaining);this.slots[i]={id,count:n};remaining-=n;if(!remaining)return true;}}
      return false;
    }
    remove(id,count=1){if(count<=0)return true;if(!this.has(id,count))return false;let remaining=count;for(let i=this.slots.length-1;i>=0;i--){const s=this.slots[i];if(!s||s.id!==id)continue;const n=Math.min(s.count,remaining);s.count-=n;remaining-=n;if(s.count<=0)this.slots[i]=null;if(!remaining)return true;}return false;}
    selected(){return this.slots[this.active]||null;}
    select(i){if(Number.isInteger(i)&&i>=0&&i<9)this.active=i;}
    swap(a,b){if(a<0||b<0||a>=36||b>=36||a===b)return;const tmp=this.slots[a];this.slots[a]=this.slots[b];this.slots[b]=tmp;}
    serialize(){return {slots:this.slots.map(cloneSlot),active:this.active,mode:this.mode};}
    restore(data){if(!data||!Array.isArray(data.slots))return false;this.slots=Array(36).fill(null);for(let i=0;i<Math.min(36,data.slots.length);i++){const s=data.slots[i];if(s&&M.item(Number(s.id))&&Number.isFinite(Number(s.count))&&s.count>0){this.slots[i]={id:Number(s.id),count:Math.min(M.item(Number(s.id)).stack||64,Math.floor(Number(s.count)))};}}this.active=Math.max(0,Math.min(8,Number(data.active)||0));return true;}
  }
  M.Inventory=Inventory;
})();

(() => {
  const M = window.ME;
  const FACES = [
    {n:[1,0,0],p:[[.5,-.5,-.5],[.5,.5,-.5],[.5,.5,.5],[.5,-.5,.5]]},
    {n:[-1,0,0],p:[[-.5,-.5,.5],[-.5,.5,.5],[-.5,.5,-.5],[-.5,-.5,-.5]]},
    {n:[0,1,0],p:[[-.5,.5,-.5],[-.5,.5,.5],[.5,.5,.5],[.5,.5,-.5]]},
    {n:[0,-1,0],p:[[-.5,-.5,.5],[-.5,-.5,-.5],[.5,-.5,-.5],[.5,-.5,.5]]},
    {n:[0,0,1],p:[[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5],[-.5,-.5,.5]]},
    {n:[0,0,-1],p:[[-.5,-.5,-.5],[-.5,.5,-.5],[.5,.5,-.5],[.5,-.5,-.5]]}
  ];
  const K = (x,y,z) => `${x},${y},${z}`;
  function hash2(x,z,seed){let n=(Math.imul(x|0,374761393)+Math.imul(z|0,668265263)+Math.imul(seed|0,1442695041))|0;n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967295;}
  function hash3(x,y,z,seed){return hash2(x*31+y*7,z*19-y*13,seed+Math.imul(y|0,1013904223));}
  class World {
    constructor(scene, materials){this.scene=scene;this.materials=materials;this.blocks=new Map();this.edits=new Map();this.chunkMeshes=new Map();this.seed=20261010;this.time=.28;this.disposed=false;}
    inBounds(x,z){return x>=-M.WORLD_HALF&&x<M.WORLD_HALF&&z>=-M.WORLD_HALF&&z<M.WORLD_HALF;}
    getBlock(x,y,z){if(!this.inBounds(x,z)||y<M.MIN_Y||y>M.MAX_Y)return null;return this.blocks.get(K(Math.round(x),Math.round(y),Math.round(z))) ?? null;}
    _put(x,y,z,id){const k=K(x,y,z);if(id===null||id===undefined)this.blocks.delete(k);else this.blocks.set(k,id);}
    generate(seed, edits=[]){
      this.clear();this.seed=(Number(seed)||20261010)>>>0;this.edits=new Map();
      const half=M.WORLD_HALF, sea=3, seedN=this.seed;
      for(let x=-half;x<half;x++)for(let z=-half;z<half;z++){
        const riverCenter=-19+Math.sin((z+seedN%37)*.085)*8+Math.sin(z*.027)*5;
        const river=Math.abs(x-riverCenter)<1.45;
        const broad=Math.sin((x+seedN%23)*.105)*2.1+Math.cos((z-seedN%31)*.087)*2.2;
        const detail=(hash2(x,z,seedN)-.5)*2.6;
        let h=Math.round(4+broad+detail);
        if(river)h=1+Math.round(hash2(x,z,seedN+3));
        h=Math.max(1,Math.min(12,h));
        const forest=Math.sin((x+seedN%47)*.075)+Math.cos((z-seedN%29)*.082)>.38;
        const biome=h>=10?'mountain':river?'river':h<=3?'beach':forest?'forest':'plains';
        for(let y=M.MIN_Y;y<=h;y++){
          if(y>M.MIN_Y+1 && y<h-2 && y>-3){
            const cave=Math.sin(x*.43+y*.61+seedN*.001)*Math.cos(z*.39-y*.47)*Math.sin((x+z)*.17);
            if(cave>.91 && hash3(x,y,z,seedN)>.27)continue;
          }
          let id;
          if(y===M.MIN_Y)id=2;
          else if(y===h){id=biome==='mountain'?(h>11?14:2):(biome==='beach'||biome==='river'?5:0);}
          else if(y>=h-2)id=(biome==='beach'||biome==='river')?5:1;
          else {
            const r=hash3(x,y,z,seedN);
            id=(r>.987&&y<h-2)?9:(r>.958&&y<h-2)?8:2;
          }
          this._put(x,y,z,id);
        }
        if(h<sea){for(let y=h+1;y<=sea;y++)this._put(x,y,z,7);}
        if(biome==='forest'&&hash2(x,z,seedN+19)>.976&&h>=3){
          for(let y=h+1;y<=h+3;y++)this._put(x,y,z,3);
          for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++)for(let dy=2;dy<=4;dy++){
            if(Math.abs(dx)+Math.abs(dz)+(dy===4?1:0)<=4&&hash3(x+dx,dy,z+dz,seedN+4)>.13&&!this.getBlock(x+dx,h+dy,z+dz))this._put(x+dx,h+dy,z+dz,4);
          }
        } else if(biome==='plains'&&hash2(x,z,seedN+7)>.992&&h>=3&&!this.getBlock(x,h+1,z))this._put(x,h+1,z,11);
      }
      // A small, seed-independent landmark near spawn to help first-time builders orient themselves.
      for(let x=-2;x<=2;x++)for(let z=-10;z<=-8;z++){this._put(x,4,z,6);this._put(x,5,z,6);}
      for(let x=-2;x<=2;x++){this._put(x,6,-10,3);this._put(x,6,-8,3);}
      this._put(0,4,-7,5);this._put(0,5,-7,5);
      for(const pair of edits||[]){if(!Array.isArray(pair)||pair.length!==2)continue;const key=String(pair[0]);const val=pair[1];const xyz=key.split(',').map(Number);if(xyz.length!==3||xyz.some(n=>!Number.isInteger(n)))continue;if(!this.inBounds(xyz[0],xyz[2])||xyz[1]<M.MIN_Y||xyz[1]>M.MAX_Y)continue;if(val!==null&&(!Number.isInteger(Number(val))||!M.block(Number(val))))continue;const editValue=val===null?null:Number(val);this.edits.set(K(xyz[0],xyz[1],xyz[2]),editValue);this._put(xyz[0],xyz[1],xyz[2],editValue);}
      this.rebuildAll();
    }
    clear(){for(const mesh of this.chunkMeshes.values()){this.scene.remove(mesh);mesh.geometry.dispose();}this.chunkMeshes.clear();this.blocks.clear();if(this.edits)this.edits.clear();}
    chunkAt(x,z){return {cx:Math.floor((x+M.WORLD_HALF)/M.CHUNK_SIZE),cz:Math.floor((z+M.WORLD_HALF)/M.CHUNK_SIZE)};}
    _buildChunk(cx,cz){
      const ck=`${cx},${cz}`,old=this.chunkMeshes.get(ck);if(old){this.scene.remove(old);old.geometry.dispose();this.chunkMeshes.delete(ck);}
      const buckets=Array.from({length:M.BLOCKS.length},()=>({p:[],n:[]}));
      const x0=-M.WORLD_HALF+cx*M.CHUNK_SIZE,z0=-M.WORLD_HALF+cz*M.CHUNK_SIZE;
      const x1=Math.min(x0+M.CHUNK_SIZE,M.WORLD_HALF),z1=Math.min(z0+M.CHUNK_SIZE,M.WORLD_HALF);
      for(let x=x0;x<x1;x++)for(let z=z0;z<z1;z++)for(let y=M.MIN_Y;y<=M.MAX_Y;y++){
        const id=this.getBlock(x,y,z);if(id===null||id===undefined||!M.block(id))continue;
        const bucket=buckets[id];
        for(const f of FACES){const nid=this.getBlock(x+f.n[0],y+f.n[1],z+f.n[2]);const nb=nid===null?null:M.block(nid);const cb=M.block(id);if(nb&&(!nb.transparent||nid===id))continue;
          const tri=[0,1,2,0,2,3];for(const ix of tri){const p=f.p[ix];bucket.p.push(x+p[0],y+p[1],z+p[2]);bucket.n.push(...f.n);}
        }
      }
      const positions=[],normals=[];const g=new THREE.BufferGeometry();let vCount=0;
      buckets.forEach((arr,type)=>{if(!arr.p.length)return;const verts=arr.p.length/3;const offset=vCount;for(let i=0;i<arr.p.length;i++)positions.push(arr.p[i]);for(let i=0;i<arr.n.length;i++)normals.push(arr.n[i]);vCount+=verts;g.addGroup(offset,verts,type);});
      if(!positions.length)return;
      g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));g.computeBoundingSphere();
      const mesh=new THREE.Mesh(g,this.materials);mesh.frustumCulled=true;mesh.userData={chunk:ck};this.scene.add(mesh);this.chunkMeshes.set(ck,mesh);
    }
    rebuildAll(){for(let cx=0;cx<M.WORLD_SIZE/M.CHUNK_SIZE;cx++)for(let cz=0;cz<M.WORLD_SIZE/M.CHUNK_SIZE;cz++)this._buildChunk(cx,cz);}
    rebuildAround(x,z){const {cx,cz}=this.chunkAt(x,z);this._buildChunk(cx,cz);const lx=(x+M.WORLD_HALF)%M.CHUNK_SIZE,lz=(z+M.WORLD_HALF)%M.CHUNK_SIZE;if(lx===0)this._buildChunk(cx-1,cz);if(lx===M.CHUNK_SIZE-1)this._buildChunk(cx+1,cz);if(lz===0)this._buildChunk(cx,cz-1);if(lz===M.CHUNK_SIZE-1)this._buildChunk(cx,cz+1);}
    setBlock(x,y,z,id){x=Math.round(x);y=Math.round(y);z=Math.round(z);if(!this.inBounds(x,z)||y<M.MIN_Y+1||y>M.MAX_Y)return false;const k=K(x,y,z);if(id!==null&&!M.block(id))return false;if(!this.edits.has(k)&&this.edits.size>=100000)return false;this._put(x,y,z,id);this.edits.set(k,id===null?null:id);this.rebuildAround(x,z);return true;}
    surfaceAt(x,z){x=Math.round(x);z=Math.round(z);for(let y=M.MAX_Y;y>=M.MIN_Y;y--){const id=this.getBlock(x,y,z);if(id!==null&&id!==7&&M.block(id)?.solid)return y+.5;}return M.MIN_Y+.5;}
    serializeEdits(){return Array.from(this.edits.entries());}
  }
  M.World=World;
})();

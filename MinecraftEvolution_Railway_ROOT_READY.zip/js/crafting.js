(() => {
  const M=window.ME;
  M.RECIPES=[
    {name:'Wood Planks ×4',needs:[[3,1]],out:[10,4],desc:'Turn one log into four planks.'},
    {name:'Sticks ×4',needs:[[10,2]],out:[15,4],desc:'Two planks make four sticks.'},
    {name:'Torch ×4',needs:[[19,1],[15,1]],out:[12,4],desc:'Coal plus a stick makes light.'},
    {name:'Wood Pickaxe',needs:[[10,3],[15,2]],out:[16,1],desc:'A basic tool for mining.'},
    {name:'Stone Pickaxe',needs:[[2,3],[15,2]],out:[17,1],desc:'A stronger mining tool.'},
    {name:'Wood Sword',needs:[[10,2],[15,1]],out:[21,1],desc:'Use Attack to defend yourself.'},
    {name:'Brick Blocks ×4',needs:[[2,4]],out:[6,4],desc:'Four stone blocks form decorative bricks.'},
    {name:'Glass Blocks ×2',needs:[[5,2],[19,1]],out:[13,2],desc:'A simple glass recipe for sandbox building.'}
  ];
  M.Crafting={canCraft(inv,r,mode){return mode==='creative'||r.needs.every(([id,n])=>inv.has(id,n));},craft(inv,r,mode){if(!this.canCraft(inv,r,mode))return {ok:false,reason:'Missing ingredients.'};if(mode!=='creative')for(const [id,n] of r.needs)if(!inv.remove(id,n))return {ok:false,reason:'Inventory changed; try again.'};if(!inv.add(r.out[0],r.out[1])){if(mode!=='creative')for(const [id,n] of r.needs)inv.add(id,n);return {ok:false,reason:'Inventory is full.'};}return {ok:true};}};
})();

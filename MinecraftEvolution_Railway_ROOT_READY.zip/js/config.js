(() => {
  const M = window.ME = window.ME || {};
  M.VERSION = 2;
  M.WORLD_SIZE = 80;
  M.WORLD_HALF = 40;
  M.CHUNK_SIZE = 16;
  M.MIN_Y = -4;
  M.MAX_Y = 24;
  M.BLOCKS = [
    {id:0,name:'Grass',color:0x5cae62,solid:true,placeable:true,drop:1,hardness:1},
    {id:1,name:'Dirt',color:0x8e6040,solid:true,placeable:true,drop:1,hardness:0.8},
    {id:2,name:'Stone',color:0x929ca4,solid:true,placeable:true,drop:2,hardness:2},
    {id:3,name:'Wood',color:0x966039,solid:true,placeable:true,drop:3,hardness:1.7},
    {id:4,name:'Leaves',color:0x368b4c,solid:true,placeable:true,drop:4,hardness:0.6},
    {id:5,name:'Sand',color:0xe6ce88,solid:true,placeable:true,drop:5,hardness:0.7},
    {id:6,name:'Brick',color:0xb95749,solid:true,placeable:true,drop:6,hardness:1.8},
    {id:7,name:'Water',color:0x399fe3,solid:false,placeable:true,drop:null,hardness:0,transparent:true,opacity:0.62},
    {id:8,name:'Coal Ore',color:0x414a50,solid:true,placeable:true,drop:19,hardness:2.4},
    {id:9,name:'Iron Ore',color:0xb57d60,solid:true,placeable:true,drop:20,hardness:2.8},
    {id:10,name:'Planks',color:0xc59055,solid:true,placeable:true,drop:10,hardness:1},
    {id:11,name:'Flower',color:0xf08eab,solid:false,placeable:true,drop:11,hardness:0.1},
    {id:12,name:'Torch',color:0xffc94f,solid:false,placeable:true,drop:12,hardness:0.1,emissive:0x5e3000},
    {id:13,name:'Glass',color:0x9ce8ed,solid:true,placeable:true,drop:13,hardness:0.4,transparent:true,opacity:0.38},
    {id:14,name:'Snow',color:0xf1f5f5,solid:true,placeable:true,drop:14,hardness:0.5}
  ];
  M.ITEMS = [
    ...M.BLOCKS.map(b => ({id:b.id,name:b.name,color:b.color,placeable:b.placeable,stack:64})),
    {id:15,name:'Stick',color:0xb68a5b,placeable:false,stack:64},
    {id:16,name:'Wood Pickaxe',color:0xcba16b,placeable:false,stack:1,tool:'pickaxe',power:1},
    {id:17,name:'Stone Pickaxe',color:0x9ca6ad,placeable:false,stack:1,tool:'pickaxe',power:2},
    {id:18,name:'Bread',color:0xd6a85d,placeable:false,stack:16,food:4},
    {id:19,name:'Coal',color:0x293238,placeable:false,stack:64},
    {id:20,name:'Iron Ore',color:0xb57d60,placeable:false,stack:64},
    {id:21,name:'Wood Sword',color:0xb88650,placeable:false,stack:1,tool:'sword',power:4},
    {id:22,name:'Iron Ingot',color:0xc3cbd0,placeable:false,stack:64}
  ];
  M.item = id => M.ITEMS.find(x => x.id === id) || null;
  M.block = id => M.BLOCKS[id] || null;
  M.hex = n => '#' + Number(n).toString(16).padStart(6,'0');
})();

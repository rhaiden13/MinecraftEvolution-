(() => {
  const M=window.ME;
  class MobManager {
    constructor(scene,world){this.scene=scene;this.world=world;this.mobs=[];this.clock=0;this.geometry=new THREE.BoxGeometry(1,1,1);this.materials={cow:new THREE.MeshLambertMaterial({color:0xded7c5}),head:new THREE.MeshLambertMaterial({color:0x9a826c}),hostile:new THREE.MeshLambertMaterial({color:0x493b60}),eye:new THREE.MeshBasicMaterial({color:0xe9f6ff}),leg:new THREE.MeshLambertMaterial({color:0x54483d})};}
    _part(group,mat,pos,scale){const m=new THREE.Mesh(this.geometry,mat);m.position.set(...pos);m.scale.set(...scale);group.add(m);return m;}
    spawn(type,x,z){const group=new THREE.Group();const hostile=type==='hostile';const bodyMat=hostile?this.materials.hostile:this.materials.cow;this._part(group,bodyMat,[0,.75,0],[.85,.65,1.15]);this._part(group,hostile?this.materials.head:this.materials.cow,[0,1.22,-.48],[.48,.48,.45]);this._part(group,this.materials.eye,[-.13,1.28,-.72],[.07,.07,.04]);this._part(group,this.materials.eye,[.13,1.28,-.72],[.07,.07,.04]);for(const lx of [-.27,.27])for(const lz of [-.35,.35])this._part(group,this.materials.leg,[lx,.28,lz],[.18,.56,.18]);
      const y=this.world.surfaceAt(x,z);group.position.set(x,y,z);this.scene.add(group);const mob={type,x,z,y,group,hp:hostile?8:6,dir:Math.random()*Math.PI*2,think:Math.random()*3,attack:0,phase:Math.random()*6};this.mobs.push(mob);return mob;}
    initialize(){for(let i=0;i<5;i++){let x,z,tries=0;do{x=Math.floor(Math.random()*56-28);z=Math.floor(Math.random()*56-28);tries++;}while(Math.hypot(x,z-5)<9&&tries<30);this.spawn(i===4?'animal':'animal',x,z);}}
    spawnHostileNear(px,pz){if(this.mobs.filter(m=>m.type==='hostile').length>=4)return;const a=Math.random()*Math.PI*2,d=9+Math.random()*9;const x=Math.max(-37,Math.min(37,Math.round(px+Math.cos(a)*d))),z=Math.max(-37,Math.min(37,Math.round(pz+Math.sin(a)*d)));if(Math.hypot(x-px,z-pz)>7)this.spawn('hostile',x,z);}
    update(dt,player,night,mode){this.clock+=dt;if(night&&mode==='survival'&&this.clock>10){this.clock=0;if(Math.random()<.72)this.spawnHostileNear(player.x,player.z);}
      for(const m of [...this.mobs]){m.phase+=dt*5;m.think-=dt;m.attack-=dt;
        let dx=0,dz=0;if(m.type==='hostile'&&mode==='survival'&&Math.hypot(player.x-m.x,player.z-m.z)<14){const d=Math.hypot(player.x-m.x,player.z-m.z)||1;dx=(player.x-m.x)/d;dz=(player.z-m.z)/d;if(d<1.5&&m.attack<=0){player.damage(2);m.attack=1.3;M.onToast?.('A night creature hit you!');}}
        else{if(m.think<=0){m.dir+=(Math.random()-.5)*2.5;m.think=1.5+Math.random()*3;}dx=Math.sin(m.dir);dz=Math.cos(m.dir);}
        const nx=m.x+dx*dt*(m.type==='hostile'?1.65:.55),nz=m.z+dz*dt*(m.type==='hostile'?1.65:.55);
        if(Math.abs(nx)<37&&Math.abs(nz)<37){m.x=nx;m.z=nz;m.y=this.world.surfaceAt(nx,nz);m.group.position.set(m.x,m.y+Math.sin(m.phase)*.025,m.z);m.group.rotation.y=Math.atan2(dx,dz);}
      }
    }
    attack(player,inventory,mode){let closest=null,distance=2.6;for(const m of this.mobs){const d=Math.hypot(m.x-player.x,m.z-player.z);if(d<distance){distance=d;closest=m;}}if(!closest){M.onToast?.('No creature in reach.');return false;}const held=inventory.selected(),item=held?M.item(held.id):null;const damage=item?.tool==='sword'?item.power:2;closest.hp-=damage;M.playSound?.('hit');if(closest.hp<=0){this.scene.remove(closest.group);this.mobs=this.mobs.filter(m=>m!==closest);if(mode==='survival')inventory.add(closest.type==='hostile'?19:18,closest.type==='hostile'?1:1);M.onToast?.('Creature defeated!');}else M.onToast?.('Hit!');return true;}
    serialize(){return this.mobs.map(m=>({type:m.type,x:m.x,z:m.z,hp:m.hp,dir:m.dir}));}
    restore(data){for(const m of this.mobs)this.scene.remove(m.group);this.mobs=[];if(!Array.isArray(data))return;data.slice(0,10).forEach(d=>{if(Number.isFinite(d.x)&&Number.isFinite(d.z)&&Math.abs(d.x)<38&&Math.abs(d.z)<38){const m=this.spawn(d.type==='hostile'?'hostile':'animal',d.x,d.z);m.hp=Math.max(1,Math.min(8,Number(d.hp)||5));m.dir=Number(d.dir)||0;}});}
    dispose(){for(const m of this.mobs)this.scene.remove(m.group);this.mobs=[];this.geometry.dispose();Object.values(this.materials).forEach(x=>x.dispose());}
  }
  M.MobManager=MobManager;
})();

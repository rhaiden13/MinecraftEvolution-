'use strict';

const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const net = require('node:net');
const path = require('node:path');

const root = path.resolve(__dirname, '..');

function reservePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close(error => error ? reject(error) : resolve(port));
    });
  });
}

async function waitForServer(url, child) {
  const deadline = Date.now() + 8000;
  let lastError;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`Server exited early with code ${child.exitCode}`);
    try {
      const response = await fetch(url);
      if (response.status === 200) return;
    } catch (error) {
      lastError = error;
    }
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error(`Server did not become ready${lastError ? `: ${lastError.message}` : ''}`);
}

async function main() {
  const port = await reservePort();
  const child = spawn(process.execPath, [path.join(root, 'server.js')], {
    cwd: root,
    env: { ...process.env, PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let serverOutput = '';
  child.stdout.on('data', chunk => { serverOutput += chunk; });
  child.stderr.on('data', chunk => { serverOutput += chunk; });
  const base = `http://127.0.0.1:${port}`;
  const checks = [];

  try {
    await waitForServer(`${base}/health`, child);

    const home = await fetch(`${base}/`);
    assert.equal(home.status, 200, 'home page responds with HTTP 200');
    assert.match(home.headers.get('content-type') || '', /text\/html/);
    const html = await home.text();
    assert.match(html, /id="mainMenu"/, 'main menu exists');
    assert.match(html, /js\/main\.js/, 'main game script is referenced');
    checks.push('Homepage and HTML entry point');

    const healthResponse = await fetch(`${base}/health`);
    assert.equal(healthResponse.status, 200);
    assert.deepEqual(await healthResponse.json(), { status: 'ok', app: 'Minecraft Evolution' });
    checks.push('Railway health endpoint');

    for (const [url, contentType] of [
      ['/style.css', /text\/css/],
      ['/js/config.js', /javascript/],
      ['/js/world.js', /javascript/],
      ['/js/inventory.js', /javascript/],
      ['/js/crafting.js', /javascript/],
      ['/js/storage.js', /javascript/],
      ['/js/player.js', /javascript/],
      ['/js/entities.js', /javascript/],
      ['/js/main.js', /javascript/]
    ]) {
      const response = await fetch(`${base}${url}`);
      assert.equal(response.status, 200, `${url} is served`);
      assert.match(response.headers.get('content-type') || '', contentType, `${url} has expected content type`);
    }
    checks.push('All CSS and JavaScript assets are reachable');

    for (const url of ['/server.js', '/package.json', '/.gitignore', '/does-not-exist']) {
      const response = await fetch(`${base}${url}`);
      assert.equal(response.status, 404, `${url} must not be publicly served`);
    }
    checks.push('Private config and unknown paths are not exposed');

    const post = await fetch(`${base}/`, { method: 'POST' });
    assert.equal(post.status, 405, 'unsupported methods are rejected');
    checks.push('Unsupported HTTP methods are rejected');

    console.log('Minecraft Evolution smoke tests: PASS');
    for (const check of checks) console.log(`  PASS  ${check}`);
  } finally {
    child.kill('SIGTERM');
    await Promise.race([
      new Promise(resolve => child.once('exit', resolve)),
      new Promise(resolve => setTimeout(resolve, 1500))
    ]);
    if (child.exitCode === null) child.kill('SIGKILL');
    if (serverOutput.includes('Error:')) console.error(serverOutput);
  }
}

main().catch(error => {
  console.error(`Minecraft Evolution smoke tests: FAIL\n${error.stack || error}`);
  process.exitCode = 1;
});
